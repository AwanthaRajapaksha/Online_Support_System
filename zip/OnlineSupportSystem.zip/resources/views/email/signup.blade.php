<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome to My Website</h1>
    <p>Thank you  joining us!</p>
</body>
</html>
