<?php echo e($slot); ?>

<?php /**PATH C:\Users\Awantha\Documents\GitHub\Online_Support_System\OnlineSupportSystem\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>