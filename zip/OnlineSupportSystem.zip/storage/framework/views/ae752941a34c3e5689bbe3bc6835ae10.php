<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Awantha\Documents\GitHub\Online_Support_System\OnlineSupportSystem\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>