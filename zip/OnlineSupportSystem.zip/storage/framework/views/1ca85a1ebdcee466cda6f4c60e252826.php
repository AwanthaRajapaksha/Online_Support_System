<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome to My Website</h1>
    <p>Thank you  joining us!</p>
</body>
</html>
<?php /**PATH C:\Users\Awantha\Documents\GitHub\Online_Support_System\OnlineSupportSystem\resources\views/email/signup.blade.php ENDPATH**/ ?>